<?php $__env->startSection('title', 'Pengilang'); ?>

<?php $__env->startSection('local_css'); ?>
<style>
    .tilebox-one i{
        font-size: 3.7rem !important;
        line-height: 3.5rem
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>
    <h4 class="page-title-main">Pengilang</h4>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">DOA</a></li>
        <li class="breadcrumb-item"><a href="#">Rekod Maklumat Am</a></li>
        <li class="breadcrumb-item active">Pengilang</li>
    </ol>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 col-xl-3">
            <div class="card-box tilebox-one">
                <i class="mdi mdi-chart-pie float-right text-primary"></i>
                <h6 class="text-muted text-uppercase mt-0">Jumlah Rekod</h6>
                <h2 class="mb-1" data-plugin="counterup"><?php echo e($totalpengilang); ?></h2>
                
            </div>
        </div>
    
        <div class="col-md-6 col-xl-3">
            <div class="card-box tilebox-one">
                <i class=" mdi mdi-chart-arc float-right text-primary"></i>
                <h6 class="text-muted text-uppercase mt-0">Rekod <?php echo e($bulan); ?> 2021</h6>
                <h2 class="mb-1" data-plugin="counterup"><?php echo e($totalpengilangbulanterkini); ?></h2>
                
            </div>
        </div>
    
        <div class="col-md-6 col-xl-3">
            <div class="card-box tilebox-one">
                <i class="mdi mdi-battery-charging-100 float-right text-primary mt-0"></i>
                <h6 class="text-muted text-uppercase mt-0">Aktif</h6>
                <h2 class="mb-1"><span data-plugin="counterup"><?php echo e($totalpengilangaktif); ?></span></h2>
                
            </div>
        </div>
    
        <div class="col-md-6 col-xl-3">
            <div class="card-box tilebox-one">
                <i class="mdi mdi-battery-charging-10 float-right text-primary"></i>
                <h6 class="text-muted text-uppercase mt-0">Tidak Aktif</h6>
                <h2 class="mb-1"><span data-plugin="counterup"><?php echo e($totalpengilangtidakaktif); ?></span></h2>
                
            </div>
        </div>
    
        <div class="col-12">
            <div class="card-box">
                <div class="row mb-2 mb-sm-3">
                    <div class="col-12 col-md-10">
                        <h4 class="header-title">Senarai Pengilang</div></h4>
                    <div class="col-12 col-md-2">
                        
                        <button type="button" class="btn waves-effect waves-light btn-primary float-md-right"
                        onclick="window.location='<?php echo e(route("baru.pengilang")); ?>'">Daftar Baru</button>
                        <button type="button" class="btn waves-effect waves-light btn-primary float-md-right btn-excel mr-1"
                        >Excel</button>
                    </div>
                </div>

                <?php if( Session::has( 'success' )): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <?php echo e(Session::get( 'success' )); ?>

                </div>

                <?php elseif( Session::has( 'warning' )): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <?php echo e(Session::get( 'warning' )); ?>

                </div>
                <?php endif; ?>
                
                <table class="table table-bordered m-0 table-centered tickets-list table-actions-bar dt-responsive nowrap" cellspacing="0" width="100%" id="datatable">
                    <thead>
                        <tr>
                            <th>Nama Pengilang</th>
                            <th>ROC</th>
                            <th>Telefon</th>
                            <th>Negeri</th>
                            <th>Status</th>
                            <th class="hidden-sm">Tetapan</th>
                        </tr>
                    </thead>
    
                    <tbody>
                        <?php $__currentLoopData = $pengilangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengilang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pengilang->pihak_ketiga_nama); ?></td>
                            <td><?php echo e($pengilang->pihak_ketiga_no_roc); ?></td>
                            <td><?php echo e($pengilang->pihak_ketiga_no_tel); ?></td>
                            <td><?php echo e($pengilang->pihak_ketiga_negeri); ?></td>
                            <td><?php echo e($pengilang->pihak_ketiga_status); ?></td>
                            <td>
                                <div class="btn-group dropdown">
                                    <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="<?php echo e(route('papar.pengilang', $pengilang->id)); ?>"><i class="mdi mdi-file-document-box-search-outline mr-2 text-muted font-18 vertical-middle"></i>Papar</a>
                                        <a class="dropdown-item" href="<?php echo e(route('kemaskini.pengilang', $pengilang->id)); ?>"><i class="mdi mdi-file-document-box-plus-outline mr-2 text-muted font-18 vertical-middle"></i>Kemaskini</a>
                                        <a class="dropdown-item padam" href="#" id="padam_<?php echo e($pengilang->id); ?>" ><i class="mdi mdi-file-document-box-remove-outline mr-2 text-muted font-18 vertical-middle"></i>Padam</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div><!-- end col -->
    </div>
    <!-- end row -->
</div>
<!-- end div -->
<?php $__env->startComponent('components.modal_confirm', ['id'=>'id_pengilang']); ?>
Adakah anda bersetuju untuk memadam data?
<?php echo $__env->renderComponent(); ?>

<form id="padam_submit" method='post'>
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('local_js'); ?>
<script>
$(document).ready(function () {
    var table = $('#datatable').DataTable({
        lengthChange: true,
        responsive: false,
        // scrollX: true,
        // dom: 'Bfrtip',
        buttons: [
            'excel',
        ]
        // language: {
        //     "paginate": {
        //         "previous": "<i class='mdi mdi-chevron-left'>",
        //         "next": "<i class='mdi mdi-chevron-right'>"
        //     }
        // },
        // "drawCallback": function () {
        //     $('.dataTables_paginate > .pagination').addClass('pagination-rounded');
        // }
    });

    $(".btn-excel").on("click", function() {
        table.button( '.buttons-excel' ).trigger();
    });

    // To get pengilang id
    $('.padam').on('click', function(){
        
        id = $(this).attr('id');
        id = id.split('_');

        $('.bs-example-modal-sm').modal('show');
        $('#padam_submit').attr('action','form/pengilang/delete/' + id[1]);

    });

    // Submit
    $('#teruskan').on('click', function(){
        $('#padam_submit').submit();
    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aman/Documents/Personal/doa/resources/views/maklumat_am/main_pengilang.blade.php ENDPATH**/ ?>