<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <title>DOA - <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- For AJAX request -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="/assets/images/logo-tab v1.ico">

        <!-- third party css -->
        <link href="/assets/libs/datatables/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/datatables/buttons.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/datatables/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/datatables/select.bootstrap4.css" rel="stylesheet" type="text/css" />
       
        <link href="/assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" />
        <link href="/assets/libs/switchery/switchery.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/libs/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />

    </head>

    <style>
        .logo-box h5{
            line-height: 1.3rem
        }
    </style>

    <?php echo $__env->yieldContent('local_css'); ?>

    <body class="left-side-menu-dark">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu">

                <div class="slimscroll-menu">

                    <!-- LOGO -->
                    <div class="logo-box pt-2">
                        <h5 class="text-light">
                            Sistem Maklumat Rekod Pendaftaran
                        </h5>
                        
                        
                    </div>

                    <!-- User box -->
                    <div class="user-box">
                        <img src="/assets/images/logo-dark v2.png" alt="logo-jabatan-dark" title="Logo Jabatan" class="" height="85">
                        
                        
                    </div>

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">

                        <ul class="metismenu" id="side-menu">

                            <li class="menu-title">MENU UTAMA</li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-clipboard"></i>
                                    <span>Rekod Maklumat Am</span>
                                    <span class="menu-arrow"></span>
                                </a>

                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="<?php echo e(route('main.syarikat')); ?>">Syarikat </a></li>
                                    <li><a href="<?php echo e(route('main.agen')); ?>">Agen </a></li>
                                    <li><a href="<?php echo e(route('main.produk')); ?>">Produk </a></li>
                                    <li><a href="<?php echo e(route('main.perawis')); ?>">Perawis Aktif </a></li>
                                    <li><a href="<?php echo e(route('main.pembekal')); ?>">Pembekal </a></li>
                                    <li><a href="<?php echo e(route('main.pengilang')); ?>">Pengilang </a></li>
                                    <li><a href="<?php echo e(route('main.gudang')); ?>">Gudang </a></li>
                                    <li><a href="<?php echo e(route('main.penginvoisan')); ?>">Invoicing </a></li>
                                </ul>
                            </li>

                            <li>
                                <a href="<?php echo e(route('main.pendaftaran')); ?>">
                                    <i class="fe-edit"></i>
                                    
                                    <span>Pendaftaran (Borang A)</span>
                                </a>
                            </li>

                            <li class="menu-title">LAIN-LAIN</li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-settings"></i>
                                    <span> Tetapan </span>
                                    <span class="menu-arrow"></span>
                                </a>

                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="<?php echo e(route('view.password')); ?>">Tukar Kata Laluan</a></li>
                                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">Log Keluar</a></li>
                                </ul>
                            </li>

                        </ul>

                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->
         
            <div class="content-page">

                    <!-- Topbar Start -->
                    <div class="navbar-custom">
                        <ul class="list-unstyled topnav-menu float-right mb-0">

                            
        
                            

                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="/assets/images/users/man.png" alt="user-image" class="rounded-circle">
                                    <span class="pro-user-name ml-1">
                                        
                                        <?php echo e(Auth::user()->name); ?> <i class="mdi mdi-chevron-down"></i> 
                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <div class="dropdown-item noti-title">
                                        <h6 class="text-overflow m-0">Selamat Datang !</h6>
                                    </div>

                                    <!-- item-->
                                    

                                    <a href="<?php echo e(route('view.password')); ?>" class="dropdown-item notify-item">
                                        <i class="fe-unlock"></i> <span>Tukar Kata Laluan</span>
                                    </a>

                                    <!-- item-->
                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();" class="dropdown-item notify-item">
                                        <i class="fe-log-out"></i> <span>Log Keluar</span>
                                    </a>

                                </div>
                            </li>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                            
                        </ul>

                        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                            <li>
                                <button class="button-menu-mobile disable-btn">
                                    <i class="fe-menu"></i>
                                </button>
                            </li>

                            <?php echo $__env->yieldContent('breadcrumbs'); ?>
                            
        
                        </ul>
                    </div>
                    <!-- end Topbar -->



                   
                <div class="content">
                      
                    <?php echo $__env->yieldContent('contents'); ?>
                    <!-- Start Content-->
                    

                </div> <!-- end content -->

                

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                              2019 - 2021 &copy; DOA Web Application
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="/assets/js/vendor.min.js"></script>

        <script src="/assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

        <!-- KNOB JS -->
        <script src="/assets/libs/jquery-knob/jquery.knob.min.js"></script>

        <!--Form Wizard-->
        <script src="/assets/libs/jquery-steps/jquery.steps.min.js"></script>

        <!-- Validation init js-->
        <script src="/assets/js/pages/borang_A.js"></script>

        <!-- third party js -->
        <script src="/assets/libs/switchery/switchery.min.js"></script>
        <script src="/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
        <script src="/assets/libs/select2/select2.min.js"></script>
        <script src="/assets/libs/jquery-mockjax/jquery.mockjax.min.js"></script>
        <script src="/assets/libs/autocomplete/jquery.autocomplete.min.js"></script>
        <script src="/assets/libs/bootstrap-select/bootstrap-select.min.js"></script>
        <script src="/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="/assets/libs/bootstrap-filestyle2/bootstrap-filestyle.min.js"></script>
        <!-- <script src="/assets/js/pages/form-advanced.init.js"></script> -->

        <!-- Required datatable js -->
        <script src="/assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="/assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="/assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="/assets/libs/jszip/jszip.min.js"></script>
        <script src="/assets/libs/pdfmake/pdfmake.min.js"></script>
        <script src="/assets/libs/pdfmake/vfs_fonts.js"></script>
        <script src="/assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="/assets/libs/datatables/buttons.print.min.js"></script>

        <!-- Responsive examples -->
        <script src="/assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="/assets/libs/datatables/responsive.bootstrap4.min.js"></script>

        <!-- App js -->
        <script src="/assets/js/app.min.js"></script>

        
        <script>
            $(document).ready(function(){
                    // for ajax to function in laravel
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                // show spinner before submitting form
                $("button[type='submit']").on("click", function(){
                    $('#loading_icon').show();
                });
            });
        </script>

        <?php echo $__env->yieldContent('local_js'); ?>
        
    </body>
</html><?php /**PATH D:\Personal\Projek\ovvsystem\doa\resources\views/layouts/app.blade.php ENDPATH**/ ?>