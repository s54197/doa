

<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('local_css'); ?>
<style>
    .wizard > .content > .body input.custom_border {
        border: 1px solid #e3eaef;
    }
    .wizard > .content > .body input:active {
        border: 1px solid #e3eaef;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>
    <h4 class="page-title-main">Pendaftaran</h4>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">DOA</a></li>
        
        <li class="breadcrumb-item active">Pendaftaran</li>
    </ol>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<!-- Start Content-->
<div class="container-fluid">

    <!-- Vertical Steps Example -->
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <h4 class="header-title mb-3">Borang A</h4>
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        Terdapat kesilapan pada data semasa mengisi borang, sila semak.
                    </div>
                <?php endif; ?>

                <form method="post" id="wizard-vertical" action="<?php echo e($jenis == 'new' ? route('pendaftaran.create') : route('pendaftaran.update',$borangAs->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                    <h3>Butiran Pemohon</h3>
                    <section>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_syarikat"><span class="text-danger">*</span>Syarikat Pendaftar:</label>
                            <div class="col-md-9">
                                <select class="form-control" name="borangA_syarikat" id="borangA_syarikat" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <option value="">Pilih Syarikat...</option>
                                    <?php $__currentLoopData = $syarikats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syarikat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=" <?php echo e($syarikat->id); ?>" id="<?php echo e($syarikat->id); ?>" <?php echo e(old('borangA_syarikat' , isset($borangAs->syarikat->syarikat_nama)?$borangAs->syarikat->syarikat_nama:null ) == $syarikat->syarikat_nama ? 'selected' : ''); ?> ><?php echo e($syarikat->syarikat_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>    
                                <?php $__errorArgs = ['borangA_syarikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_agen"><span class="text-danger">*</span>Wakil/Agen:</label>
                            <div class="col-md-9">
                                <select class="form-control" name="borangA_agen" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <option value="">Pilih Agen/Wakil...</option>
                                    <?php $__currentLoopData = $agens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=" <?php echo e($agen->id); ?>" <?php echo e(old('borangA_agen' , isset($borangAs->agen->agen_nama)?$borangAs->agen->agen_nama:null ) == $agen->agen_nama ? 'selected' : ''); ?> ><?php echo e($agen->agen_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>    
                                <?php $__errorArgs = ['borangA_agen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_tarikh_terima_kaunter"><span class="text-danger">*</span>Tarikh Terima Kaunter:</label>
                            <div class="col-md-9">
                                <input class="form-control custom_border" id="borangA_tarikh_terima_kaunter" type="text" name="borangA_tarikh_terima_kaunter" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('borangA_tarikh_terima_kaunter',isset($borangAs->borangA_tarikh_terima_kaunter)?$borangAs->borangA_tarikh_terima_kaunter:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_tarikh_terima_kaunter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_tarikh_lulus"><span class="text-danger">*</span>Tarikh Lulus:</label>
                            <div class="col-md-9">
                                <input class="form-control custom_border" id="borangA_tarikh_lulus" type="text" name="borangA_tarikh_lulus" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('borangA_tarikh_lulus',isset($borangAs->borangA_tarikh_lulus)?$borangAs->borangA_tarikh_lulus:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_tarikh_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_tarikh_tamat"><span class="text-danger">*</span>Tarikh Tamat:</label>
                            <div class="col-md-9">
                                <input class="form-control custom_border" id="borangA_tarikh_tamat" type="text" name="borangA_tarikh_tamat" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('borangA_tarikh_tamat',isset($borangAs->borangA_tarikh_tamat)?$borangAs->borangA_tarikh_tamat:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_tarikh_tamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_wakil_syarikat">Wakil Syarikat:</label>
                            <div class="col-md-9">
                                <input type="text" id="borangA_wakil_syarikat" name="borangA_wakil_syarikat" class="form-control custom_border" placeholder="Nama wakil" value="<?php echo e(old('borangA_wakil_syarikat',isset($borangAs->borangA_wakil_syarikat)?$borangAs->borangA_wakil_syarikat:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_wakil_syarikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_sijil_no_siri">Sijil Nombor Siri:</label>
                            <div class="col-md-9">
                                <input type="text" id="borangA_sijil_no_siri" name="borangA_sijil_no_siri" class="form-control custom_border" placeholder="Sijil Nombor Siri" value="<?php echo e(old('borangA_sijil_no_siri',isset($borangAs->borangA_sijil_no_siri)?$borangAs->borangA_sijil_no_siri:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_sijil_no_siri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                            </div>
                        </div>
                    </section>
                    <h3>Butiran Keluaran</h3>
                    <section>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_dagangan"><span class="text-danger">*</span>Nama Dagangan:</label>
                            <div class="col-md-9">
                                <select class="form-control" name="borangA_dagangan" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <option value="">Pilih Dagangan...</option>
                                    <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=" <?php echo e($produk->id); ?>" <?php echo e(old('borangA_dagangan' , isset($borangAs->produk->produk_nama)?$borangAs->produk->produk_nama:null ) == $produk->produk_nama ? 'selected' : ''); ?> ><?php echo e($produk->produk_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>    
                                <?php $__errorArgs = ['borangA_dagangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_jenis_pendaftaran"><span class="text-danger">*</span>Jenis Pendaftaran:</label>
                            <div class="col-md-9">
                                <input type="text" id="borangA_jenis_pendaftaran" name="borangA_jenis_pendaftaran" class="form-control custom_border" placeholder="Jenis Pendaftaran " value="<?php echo e(old('borangA_jenis_pendaftaran',isset($borangAs->borangA_jenis_pendaftaran)?$borangAs->borangA_jenis_pendaftaran:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_jenis_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_no_pendaftaran"><span class="text-danger">*</span>Nombor Pendaftaran:</label>
                            <div class="col-md-9">
                                <input type="text" id="borangA_no_pendaftaran" name="borangA_no_pendaftaran" class="form-control custom_border" placeholder="Nombor Pendaftaran " value="<?php echo e(old('borangA_no_pendaftaran',isset($borangAs->borangA_no_pendaftaran)?$borangAs->borangA_no_pendaftaran:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_no_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </section>
                    <h3>Butiran Aktiviti Perniagaan</h3>
                    <section>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_perniagaan_aktiviti"><span class="text-danger">*</span>Nyatakan aktiviti utama perniagaan:</label>
                            <div class="col-md-5">
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_perniagaan_mengimport" name="borangA_perniagaan_mengimport" type="checkbox" value="1" <?php echo e(old('borangA_perniagaan_mengimport',isset($borangAs->borangA_perniagaan_mengimport)?$borangAs->borangA_perniagaan_mengimport:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_perniagaan_mengimport">
                                        Mengimport
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_perniagaan_lain" name="borangA_perniagaan_lain" type="checkbox" value="1" <?php echo e(old('borangA_perniagaan_lain',isset($borangAs->borangA_perniagaan_lain)?$borangAs->borangA_perniagaan_lain:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_perniagaan_lain">
                                        Lain-lain (nyatakan)
                                    </label>
                                </div>
                                <?php $__errorArgs = ['borangA_perniagaan_lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_perniagaan_mengilang" name="borangA_perniagaan_mengilang" type="checkbox" value="1" <?php echo e(old('borangA_perniagaan_mengilang',isset($borangAs->borangA_perniagaan_mengilang)?$borangAs->borangA_perniagaan_mengilang:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_perniagaan_mengilang">
                                        Mengilang
                                    </label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['borangA_perniagaan_aktiviti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class='text-danger'><?php echo e($message); ?></small> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-9 offset-md-3">
                                <input type="text" id="borangA_perniagaan_lain_maklumat" name="borangA_perniagaan_lain_maklumat" class="form-control custom_border" placeholder="Lain-lain Aktiviti" value="<?php echo e(old('borangA_perniagaan_lain_maklumat',isset($borangAs->borangA_perniagaan_lain_maklumat)?$borangAs->borangA_perniagaan_lain_maklumat:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_perniagaan_lain_maklumat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_mengilang"><span class="text-danger">*</span>Jika aktiviti adalah mengilang, nyatakan aktiviti yang ingin dijalankan:</label>
                            <div class="col-md-5">
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_menyedia" name="borangA_mengilang_menyedia" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_menyedia',isset($borangAs->borangA_mengilang_menyedia)?$borangAs->borangA_mengilang_menyedia:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_menyedia">
                                        Menyedia
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_merumus" name="borangA_mengilang_merumus" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_merumus',isset($borangAs->borangA_mengilang_merumus)?$borangAs->borangA_mengilang_merumus:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_merumus">
                                        Merumus
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_mensebati" name="borangA_mengilang_mensebati" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_mensebati',isset($borangAs->borangA_mengilang_mensebati)?$borangAs->borangA_mengilang_mensebati:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_mensebati">
                                        Mensebati
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_mencampur" name="borangA_mengilang_mencampur" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_mencampur',isset($borangAs->borangA_mengilang_mencampur)?$borangAs->borangA_mengilang_mencampur:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_mencampur">
                                        Mencampur
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_melabel" name="borangA_mengilang_melabel" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_melabel',isset($borangAs->borangA_mengilang_melabel)?$borangAs->borangA_mengilang_melabel:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_melabel">
                                        Melabel/Melabel semula
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_mempek" name="borangA_mengilang_mempek" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_mempek',isset($borangAs->borangA_mengilang_mempek)?$borangAs->borangA_mengilang_mempek:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_mempek">
                                        Mempek/Mempek semula
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_membuat" name="borangA_mengilang_membuat" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_membuat',isset($borangAs->borangA_mengilang_membuat)?$borangAs->borangA_mengilang_membuat:null) == "TRUE" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_membuat">
                                        Membuat
                                    </label>
                                </div>
                                <div class="checkbox checkbox-primary">
                                    <input id="borangA_mengilang_lain" name="borangA_mengilang_lain" type="checkbox" value="1" <?php echo e(old('borangA_mengilang_lain',isset($borangAs->borangA_mengilang_lain)?$borangAs->borangA_mengilang_lain:null) == "Lain-lain (nyatakan)" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label for="borangA_mengilang_lain">
                                        Lain-lain (nyatakan)
                                    </label>
                                </div>
                                <?php $__errorArgs = ['borangA_mengilang_lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php $__errorArgs = ['borangA_mengilang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class='text-danger'><?php echo e($message); ?></small> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row" id="borangA_mengilang_lain_maklumat_div">
                            <div class="col-md-9 offset-md-3">
                                <input type="text" id="borangA_mengilang_lain_maklumat" name="borangA_mengilang_lain_maklumat" class="form-control custom_border" placeholder="Lain-lain Aktiviti" value="<?php echo e(old('borangA_mengilang_lain_maklumat',isset($borangAs->borangA_mengilang_lain_maklumat)?$borangAs->borangA_mengilang_lain_maklumat:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_mengilang_lain_maklumat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_pengilang"><span class="text-danger">*</span>Pengilang/Pembekal:</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_pengilang[]" id="borangA_pengilang" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $pengilang_pembekals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengilang_pembekal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?>
                                            <?php $__currentLoopData = $borangIds->pihakketigas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pengilang_pembekal->id); ?>" <?php echo e(old('borangA_pengilang[]' , isset($value->id)?$value->id:null ) == $pengilang_pembekal->id ? 'selected' : ''); ?>><?php echo e($pengilang_pembekal->pihak_ketiga_nama); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($pengilang_pembekal->id); ?>" <?php echo e(old('borangA_pengilang[]' , isset($value->id)?$value->id:null ) == $pengilang_pembekal->id ? 'selected' : ''); ?>><?php echo e($pengilang_pembekal->pihak_ketiga_nama); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_pengilang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_pengilang_kontrak"><span class="text-danger">*</span>Pengilang Kontrak:</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_pengilang_kontrak[]" id="borangA_pengilang_kontrak" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $pengilangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengilang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?> 
                                            <?php $__currentLoopData = $borangIds->pengilangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pengilang->id); ?>" <?php echo e(old('borangA_pengilang_kontrak[]' , isset($value->id)?$value->id:null ) == $pengilang->id ? 'selected' : ''); ?> ><?php echo e($pengilang->pihak_ketiga_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($pengilang->id); ?>" <?php echo e(old('borangA_pengilang_kontrak[]' , isset($value->id)?$value->id:null ) == $pengilang->id ? 'selected' : ''); ?>><?php echo e($pengilang->pihak_ketiga_nama); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_pengilang_kontrak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_penginvoisan"><span class="text-danger">*</span>Invoicing:</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_penginvoisan[]" id="borangA_penginvoisan" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $penginvoisans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penginvoisan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?>
                                            <?php $__currentLoopData = $borangIds->penginvoisans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($penginvoisan->id); ?>" <?php echo e(old('borangA_penginvoisan[]' , isset($value->id)?$value->id:null ) == $penginvoisan->id ? 'selected' : ''); ?> ><?php echo e($penginvoisan->penginvoisan_nama); ?></option>                                       
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($penginvoisan->id); ?>" <?php echo e(old('borangA_penginvoisan[]' , isset($value->id)?$value->id:null ) == $penginvoisan->id ? 'selected' : ''); ?>><?php echo e($penginvoisan->penginvoisan_nama); ?> </option>
                                        <?php endif; ?>     
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_penginvoisan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_gudang"><span class="text-danger">*</span>Gudang:</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_gudang[]" id="borangA_gudang" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $gudangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gudang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?>
                                            <?php $__currentLoopData = $borangIds->gudangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gudang->id); ?>" <?php echo e(old('borangA_gudang[]' , isset($value->id)?$value->id:null ) == $gudang->id ? 'selected' : ''); ?>><?php echo e($gudang->gudang_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($gudang->id); ?>" <?php echo e(old('borangA_gudang[]' , isset($value->id)?$value->id:null ) == $gudang->id ? 'selected' : ''); ?>><?php echo e($gudang->gudang_nama); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_gudang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </section>
                    <h3>Butiran Perawis Aktif, Lengai, Kandungan & Rumusan</h3>
                    <section>
                        
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_perawis_aktif"><span class="text-danger">*</span>Perawis Aktif:</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_perawis_aktif[]" id="borangA_perawis_aktif" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $perawiss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perawis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?>
                                            <?php $__currentLoopData = $borangIds->perawiss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($perawis->id); ?>" <?php echo e(old('borangA_perawis_aktif[]' , isset($value->id)?$value->id:null ) == $perawis->id ? 'selected' : ''); ?>><?php echo e($perawis->perawis_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($perawis->id); ?>" <?php echo e(old('borangA_perawis_aktif[]' , isset($value->id)?$value->id:null ) == $perawis->id ? 'selected' : ''); ?>><?php echo e($perawis->perawis_nama); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_perawis_aktif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_perawis_kod"><span class="text-danger">*</span>Nombor Kod:</label>
                            <div class="col-md-9">
                                <input type="text" id="borangA_perawis_kod" name="borangA_perawis_kod" class="form-control custom_border" placeholder="Nombor Kod" value="<?php echo e(old('borangA_perawis_kod',isset($borangAs->borangA_perawis_kod)?$borangAs->borangA_perawis_kod:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_perawis_kod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_perawis_perumusan"><span class="text-danger">*</span>Jenis Perumusan:</label>
                            <div class="col-md-9">
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_bahan_teknikal_pepejal_tc' name='borangA_perawis_perumusan' class='custom-control-input' value='Bahan Teknikal Pepejal (TC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Bahan Teknikal Pepejal (TC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_bahan_teknikal_pepejal_tc'>Bahan Teknikal Pepejal (TC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_bahan_teknikal_separa_pepejal_tc' name='borangA_perawis_perumusan' class='custom-control-input' value='Bahan Teknikal Separa Pepejal (TC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Bahan Teknikal Separa Pepejal (TC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_bahan_teknikal_separa_pepejal_tc'>Bahan Teknikal Separa Pepejal (TC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_bahan_teknikal_cecair_tc' name='borangA_perawis_perumusan' class='custom-control-input' value='Bahan Teknikal Cecair (TC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Bahan Teknikal Cecair (TC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_bahan_teknikal_cecair_tc'>Bahan Teknikal Cecair (TC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_teknikal_pepejal_tk' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Teknikal Pepejal (TK)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Teknikal Pepejal (TK)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_teknikal_pepejal_tk'>Pekatan Teknikal Pepejal (TK)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_teknikal_separa_pepejal_tk' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Teknikal Separa Pepejal (TK)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Teknikal Separa Pepejal (TK)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_teknikal_separa_pepejal_tk'>Pekatan Teknikal Separa Pepejal (TK)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_teknikal_cecair_tk' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Teknikal Cecair (TK)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Teknikal Cecair (TK)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_teknikal_cecair_tk'>Pekatan Teknikal Cecair (TK)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_serbuk_bancuh_wp' name='borangA_perawis_perumusan' class='custom-control-input' value='Serbuk Bancuh (WP)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Serbuk Bancuh (WP)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_serbuk_bancuh_wp'>Serbuk Bancuh (WP)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_serbuk_bancuh_sp' name='borangA_perawis_perumusan' class='custom-control-input' value='Serbuk Bancuh (SP)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Serbuk Bancuh (SP)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_serbuk_bancuh_sp'>Serbuk Bancuh (SP)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_butir_terserak_air_wg' name='borangA_perawis_perumusan' class='custom-control-input' value='Butir Terserak Air (WG)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Butir Terserak Air (WG)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_butir_terserak_air_wg'>Butir Terserak Air (WG)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_butir_larut_air_sg' name='borangA_perawis_perumusan' class='custom-control-input' value='Butir Larut Air (SG)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Butir Larut Air (SG)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_butir_larut_air_sg'>Butir Larut Air (SG)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_butir_gr' name='borangA_perawis_perumusan' class='custom-control-input' value='Butir (GR)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Butir (GR)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_butir_gr'>Butir (GR)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_butir_terkapsul_cg' name='borangA_perawis_perumusan' class='custom-control-input' value='Butir Terkapsul (CG)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Butir Terkapsul (CG)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_butir_terkapsul_cg'>Butir Terkapsul (CG)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_larut_air_sl' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Larut Air (SL)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Larut Air (SL)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_larut_air_sl'>Pekatan Larut Air (SL)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_larut_minyak_ol' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair Larut Minyak (OL)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair Larut Minyak (OL)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_larut_minyak_ol'>Cecair Larut Minyak (OL)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_isipadu_ultrarendah_ul' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair Isipadu Ultrarendah (UL)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair Isipadu Ultrarendah (UL)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_isipadu_ultrarendah_ul'>Cecair Isipadu Ultrarendah (UL)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_teremulsi_ec' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Teremulsi (EC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Teremulsi (EC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_teremulsi_ec'>Pekatan Teremulsi (EC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_mikro-emulsi_me' name='borangA_perawis_perumusan' class='custom-control-input' value='Mikro-emulsi (ME)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Mikro-emulsi (ME)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_mikro-emulsi_me'>Mikro-emulsi (ME)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_emulsi,_minyak_dalam_air_ew' name='borangA_perawis_perumusan' class='custom-control-input' value='Emulsi, Minyak Dalam Air (EW)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Emulsi, Minyak Dalam Air (EW)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_emulsi,_minyak_dalam_air_ew'>Emulsi, Minyak Dalam Air (EW)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_emulsi,_air_dalam_minyak_eo' name='borangA_perawis_perumusan' class='custom-control-input' value='Emulsi, Air Dalam Minyak (EO)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Emulsi, Air Dalam Minyak (EO)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_emulsi,_air_dalam_minyak_eo'>Emulsi, Air Dalam Minyak (EO)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_ampaian_sc' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Ampaian (SC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Ampaian (SC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_ampaian_sc'>Pekatan Ampaian (SC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_ampaian_od' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Ampaian (OD)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Ampaian (OD)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_ampaian_od'>Pekatan Ampaian (OD)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_ampaian_kapsul_cs' name='borangA_perawis_perumusan' class='custom-control-input' value='Ampaian Kapsul (CS)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Ampaian Kapsul (CS)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_ampaian_kapsul_cs'>Ampaian Kapsul (CS)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_terserak_air_dc' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Terserak Air (DC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Terserak Air (DC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_terserak_air_dc'>Pekatan Terserak Air (DC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_ampaian-emulsi_se' name='borangA_perawis_perumusan' class='custom-control-input' value='Ampaian-emulsi (SE)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Ampaian-emulsi (SE)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_ampaian-emulsi_se'>Ampaian-emulsi (SE)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_lingkaran_nyamuk_mc' name='borangA_perawis_perumusan' class='custom-control-input' value='Lingkaran Nyamuk (MC)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Lingkaran Nyamuk (MC)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_lingkaran_nyamuk_mc'>Lingkaran Nyamuk (MC)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_kepingan_meruap_mv' name='borangA_perawis_perumusan' class='custom-control-input' value='Kepingan Meruap (MV)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Kepingan Meruap (MV)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_kepingan_meruap_mv'>Kepingan Meruap (MV)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_aerosol_ae' name='borangA_perawis_perumusan' class='custom-control-input' value='Aerosol (AE)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Aerosol (AE)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_aerosol_ae'>Aerosol (AE)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_meruap_lv' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair Meruap (LV)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair Meruap (LV)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_meruap_lv'>Cecair Meruap (LV)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_serbuk_sentuh_cp' name='borangA_perawis_perumusan' class='custom-control-input' value='Serbuk Sentuh (CP)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Serbuk Sentuh (CP)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_serbuk_sentuh_cp'>Serbuk Sentuh (CP)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_tin_asap_fd' name='borangA_perawis_perumusan' class='custom-control-input' value='Tin Asap (FD)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Tin Asap (FD)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_tin_asap_fd'>Tin Asap (FD)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_gas_ga' name='borangA_perawis_perumusan' class='custom-control-input' value='Gas (GA)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Gas (GA)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_gas_ga'>Gas (GA)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_perekat_pa' name='borangA_perawis_perumusan' class='custom-control-input' value='Perekat (PA)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Perekat (PA)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_perekat_pa'>Perekat (PA)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_titis_sa' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair Titis (SA)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair Titis (SA)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_titis_sa'>Cecair Titis (SA)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_curah_po' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair Curah (PO)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair Curah (PO)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_curah_po'>Cecair Curah (PO)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_umpan_rb' name='borangA_perawis_perumusan' class='custom-control-input' value='Umpan (RB)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Umpan (RB)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_umpan_rb'>Umpan (RB)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_umpan_berbutir_gb' name='borangA_perawis_perumusan' class='custom-control-input' value='Umpan Berbutir (GB)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Umpan Berbutir (GB)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_umpan_berbutir_gb'>Umpan Berbutir (GB)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_umpan_berbungkah_bb' name='borangA_perawis_perumusan' class='custom-control-input' value='Umpan Berbungkah (BB)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Umpan Berbungkah (BB)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_umpan_berbungkah_bb'>Umpan Berbungkah (BB)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_umpan_cb' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Umpan (CB)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Umpan (CB)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_umpan_cb'>Pekatan Umpan (CB)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_gris_gs' name='borangA_perawis_perumusan' class='custom-control-input' value='Gris (GS)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Gris (GS)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_gris_gs'>Gris (GS)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_pekatan_pengabutan_panas_hn' name='borangA_perawis_perumusan' class='custom-control-input' value='Pekatan Pengabutan Panas (HN)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Pekatan Pengabutan Panas (HN)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_pekatan_pengabutan_panas_hn'>Pekatan Pengabutan Panas (HN)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_debu_dp' name='borangA_perawis_perumusan' class='custom-control-input' value='Debu (DP)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Debu (DP)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_debu_dp'>Debu (DP)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_tablet_dt' name='borangA_perawis_perumusan' class='custom-control-input' value='Tablet (DT)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Tablet (DT)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_tablet_dt'>Tablet (DT)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_cecair_al' name='borangA_perawis_perumusan' class='custom-control-input' value='Cecair (AL)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Cecair (AL)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_cecair_al'>Cecair (AL)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_serbuk_ap' name='borangA_perawis_perumusan' class='custom-control-input' value='Serbuk (AP)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Serbuk (AP)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_serbuk_ap'>Serbuk (AP)</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_krim' name='borangA_perawis_perumusan' class='custom-control-input' value='Krim'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Krim' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_krim'>Krim</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_syampu' name='borangA_perawis_perumusan' class='custom-control-input' value='Syampu'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Syampu' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_syampu'>Syampu</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_kapur_tulis' name='borangA_perawis_perumusan' class='custom-control-input' value='Kapur Tulis'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Kapur Tulis' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_kapur_tulis'>Kapur Tulis</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_ceper' name='borangA_perawis_perumusan' class='custom-control-input' value='Ceper'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Ceper' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_ceper'>Ceper</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_until' name='borangA_perawis_perumusan' class='custom-control-input' value='Until'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Until' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_until'>Until</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_relang_leher' name='borangA_perawis_perumusan' class='custom-control-input' value='Relang Leher'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Relang Leher' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_relang_leher'>Relang Leher</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_umpan_lipas_pepejal' name='borangA_perawis_perumusan' class='custom-control-input' value='Umpan Lipas Pepejal'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Umpan Lipas Pepejal' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_umpan_lipas_pepejal'>Umpan Lipas Pepejal</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_gel' name='borangA_perawis_perumusan' class='custom-control-input' value='Gel'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Gel' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_gel'>Gel</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_uncang_butir' name='borangA_perawis_perumusan' class='custom-control-input' value='Uncang Butir'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Uncang Butir' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_uncang_butir'>Uncang Butir</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_umpan_anai-anai' name='borangA_perawis_perumusan' class='custom-control-input' value='Umpan Anai-anai'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Umpan Anai-anai' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_umpan_anai-anai'>Umpan Anai-anai</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_kelambu' name='borangA_perawis_perumusan' class='custom-control-input' value='Kelambu'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Kelambu' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_kelambu'>Kelambu</label>
                                </div>
                                <div class='custom-control custom-radio custom-control-inline'>
                                    <input type='radio' id='borangA_perawis_perumusan_lain-lain_nyatakan' name='borangA_perawis_perumusan' class='custom-control-input' value='Lain-lain (nyatakan)'
                                    <?php echo e(old('borangA_perawis_perumusan', isset($borangAs->borangA_perawis_perumusan)?$borangAs->borangA_perawis_perumusan:null) == 'Lain-lain (nyatakan)' ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <label class='custom-control-label' for='borangA_perawis_perumusan_lain-lain_nyatakan'>Lain-lain (nyatakan)</label>
                                </div>
                                <?php $__errorArgs = ['borangA_perawis_perumusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-9 offset-md-3">
                                <input type="text" id="borangA_perawis_perumusan_lain" name="borangA_perawis_perumusan_lain" class="form-control custom_border" placeholder="Lain-lain Perumusan" value="<?php echo e(old('borangA_perawis_perumusan_lain',isset($borangAs->borangA_perawis_perumusan_lain)?$borangAs->borangA_perawis_perumusan_lain:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                <?php $__errorArgs = ['borangA_perawis_perumusan_lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label my-md-0" for="borangA_perawis_pengilang"><span class="text-danger">*</span>Sumber bagi racun makhluk perosak (Pengilang):</label>
                            <div class="col-md-9">
                                <select class="select2 form-control form-control-sm select2-multiple" name="borangA_perawis_pengilang[]" id="borangA_perawis_pengilang" multiple="multiple" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                    <?php $__currentLoopData = $pengilangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengilang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($borangAs)): ?>
                                            <?php $__currentLoopData = $borangIds->perawis_pengilangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pengilang->id); ?>" <?php echo e(old('borangA_perawis_pengilang[]' , isset($value->id)?$value->id:null ) == $pengilang->id ? 'selected' : ''); ?>><?php echo e($pengilang->pihak_ketiga_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($pengilang->id); ?>" <?php echo e(old('borangA_perawis_pengilang[]' , isset($value->id)?$value->id:null ) == $pengilang->id ? 'selected' : ''); ?>><?php echo e($pengilang->pihak_ketiga_nama); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>  
                                <?php $__errorArgs = ['borangA_perawis_pengilang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class='text-danger'><?php echo e($message); ?></small> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <input id="borang_A" type="hidden" value="<?php echo e($jenis); ?>"/>
                    </section>
                </form>
                <!-- End #wizard-vertical -->
            </div>
        </div>
    </div><!-- End row -->

</div> <!-- end container-fluid -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('local_js'); ?>
<script>
$(document).ready(function(){

    // initialize date field using datepicker plugin
    $('input[name="borangA_tarikh_terima_kaunter"]').datepicker();
    $('input[name="borangA_tarikh_terima_kaunter"]').attr("placeholder","Tarikh Terima Kaunter - Pilih dari kalendar");
    $('input[name="borangA_tarikh_lulus"]').datepicker();
    $('input[name="borangA_tarikh_lulus"]').attr("placeholder","Tarikh Lulus - Pilih dari kalendar");
    $('input[name="borangA_tarikh_tamat"]').datepicker();
    $('input[name="borangA_tarikh_tamat"]').attr("placeholder","Tarikh Tamat - Pilih dari kalendar");

    //  intialize multiselect option using select2 plugin
    $('.select2').select2({
        width:"100%",
        maximumSelectionLength: 4,
    });
    $('#borangA_pengilang_kontrak').select2({
        width:"100%",
        maximumSelectionLength: 10,
    });
    $('#borangA_gudang').select2({
        width:"100%",
        maximumSelectionLength: 5,
    });

    $('#borangA_syarikat').on("change",function() {
        var id = $(this).find(':selected')[0].id;
        console.log(id);
        $.ajax({
            url : "getWakil/"+id,
            type : "GET",
            datatype: 'json',
            success : function(data) {
                $.each(data.data, function(key, resp) {    
                    $('#borangA_wakil_syarikat').val(resp.syarikat_wakil);
                });
            }  
        });
    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Projek\ovvsystem\doa\resources\views/pendaftaran/forms/borang_A.blade.php ENDPATH**/ ?>