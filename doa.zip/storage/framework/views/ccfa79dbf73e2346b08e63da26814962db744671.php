

<?php $__env->startSection('title', 'Syarikat'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>
    <h4 class="page-title-main">Syarikat</h4>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">DOA</a></li>
        <li class="breadcrumb-item"><a href="#">Rekod Maklumat Am</a></li>
        <li class="breadcrumb-item active">Syarikat</li>
    </ol>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card-box px-4">
                <h4 class="header-title"><?php echo e($tajuk); ?> Syarikat</h4>
                <hr class="mb-3">
                
    
                <div class="row">
                    <div class="col-12">
                        <div>
                            <form method="POST" class="form-horizontal" role="form" action="<?php echo e($jenis == 'new' ? route('syarikat.create') : route('syarikat.update',$syarikats->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_nama"><span class="text-danger">*</span>Nama syarikat:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_nama" name="syarikat_nama" class="form-control" placeholder="Nama Syarikat" value="<?php echo e(old('syarikat_nama',isset($syarikats->syarikat_nama)?$syarikats->syarikat_nama:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_no_roc"><span class="text-danger">*</span>Nombor pendaftaran (ROC):</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_no_roc" name="syarikat_no_roc" class="form-control" placeholder="Nombor Pendaftaran (ROC)" value="<?php echo e(old('syarikat_no_roc',isset($syarikats->syarikat_no_roc)?$syarikats->syarikat_no_roc:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_no_roc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_tarikh_roc"><span class="text-danger">*</span>Tarikh pendaftaran (ROC)</label>
                                    <div class="col-md-8">
                                        <input class="form-control" id="syarikat_tarikh_roc" type="text" autocomplete="off" name="syarikat_tarikh_roc" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('syarikat_tarikh_roc',isset($syarikats->syarikat_tarikh_roc)?$syarikats->syarikat_tarikh_roc:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_tarikh_roc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mb-0 mb-sm-2">
                                    <label class="col-md-3 col-form-label" for="syarikat_alamat"><span class="text-danger">*</span>Alamat syarikat:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_bangunan" name="syarikat_bangunan" class="form-control" placeholder="Bangunan" value="<?php echo e(old('syarikat_bangunan',isset($syarikats->syarikat_bangunan)?$syarikats->syarikat_bangunan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <input type="text" id="syarikat_jalan" name="syarikat_jalan" class="form-control mt-2" placeholder="Jalan" value="<?php echo e(old('syarikat_jalan',isset($syarikats->syarikat_jalan)?$syarikats->syarikat_jalan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mt-0 mt-sm-2 mb-0 mb-sm-2">
                                    <label class="col-md-3 col-form-label" for="syarikat_alamat_tambahan"></label>
                                    <div class="col-md-2 mb-2 mb-sm-0">
                                        <input type="number" id="syarikat_poskod" name="syarikat_poskod" class="form-control" placeholder="Poskod" value="<?php echo e(old('syarikat_poskod',isset($syarikats->syarikat_poskod)?$syarikats->syarikat_poskod:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_poskod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3 mb-2 mb-sm-0">
                                        <input type="text" id="syarikat_bandar" name="syarikat_bandar" class="form-control" placeholder="Bandar" value="<?php echo e(old('syarikat_bandar',isset($syarikats->syarikat_bandar)?$syarikats->syarikat_bandar:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_bandar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3">
                                        <select class="form-control" name="syarikat_negeri" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negeri...</option>
                                            <option value="Johor" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Johor" ? 'selected' : ''); ?>>Johor</option>
                                            <option value="Melaka" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Melaka" ? 'selected' : ''); ?>>Melaka</option>
                                            <option value="Negeri Sembilan" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Negeri Sembilan" ? 'selected' : ''); ?>>Negeri Sembilan</option>
                                            <option value="Selangor" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Selangor" ? 'selected' : ''); ?>>Selangor</option>
                                            <option value="Wilayah Persekutuan Putrajaya, Selangor" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Wilayah Persekutuan Putrajaya, Selangor" ? 'selected' : ''); ?>>Wilayah Persekutuan Putrajaya, Selangor</option>
                                            <option value="Wilayah Persekutuan Kuala Lumpur" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Wilayah Persekutuan Kuala Lumpur" ? 'selected' : ''); ?>>Wilayah Persekutuan Kuala Lumpur</option>
                                            <option value="Pahang" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Pahang" ? 'selected' : ''); ?>>Pahang</option>
                                            <option value="Terengganu" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Terengganu" ? 'selected' : ''); ?>>Terengganu</option>
                                            <option value="Kelantan" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Kelantan" ? 'selected' : ''); ?>>Kelantan</option>
                                            <option value="Perak" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Perak" ? 'selected' : ''); ?>>Perak</option>
                                            <option value="Kedah" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Kedah" ? 'selected' : ''); ?>>Kedah</option>
                                            <option value="Perlis" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Perlis" ? 'selected' : ''); ?>>Perlis</option>
                                            <option value="Pulau Pinang" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Pulau Pinang" ? 'selected' : ''); ?>>Pulau Pinang</option>
                                            <option value="Sabah" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Sabah" ? 'selected' : ''); ?>>Sabah</option>
                                            <option value="Sarawak" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Sarawak" ? 'selected' : ''); ?>>Sarawak</option>
                                            <option value="Wilayah Persekutuan Labuan, Sabah" <?php echo e(old('syarikat_negeri',isset($syarikats->syarikat_negeri)?$syarikats->syarikat_negeri:null) == "Wilayah Persekutuan Labuan, Sabah" ? 'selected' : ''); ?>>Wilayah Persekutuan Labuan, Sabah</option>
                                        </select>                                    
                                        <?php $__errorArgs = ['syarikat_negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_negeri_luar_malaysia">Negeri (luar malaysia):</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_negeri_luar_malaysia" name="syarikat_negeri_luar_malaysia" class="form-control" placeholder="Negeri (luar malaysia) syarikat" value="<?php echo e(old('syarikat_negeri_luar_malaysia',isset($syarikats->syarikat_negeri_luar_malaysia)?$syarikats->syarikat_negeri_luar_malaysia:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_negeri_luar_malaysia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_negara"><span class="text-danger">*</span>Negara:</label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="syarikat_negara" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negara...</option>
                                            <?php $__currentLoopData = $list_negara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $negara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($negara->negara_nama); ?>" <?php echo e(old('syarikat_negara' , isset($syarikats->syarikat_negara)?$syarikats->syarikat_negara:null ) == $negara->negara_nama ? 'selected' : ''); ?> ><?php echo e($negara->negara_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>   
                                        <?php $__errorArgs = ['syarikat_negara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mb-0 mb-sm-2">
                                    <div class="col-md-8 offset-md-3 col-12 pl-4 pl-sm-2">
                                        <div class="checkbox checkbox-primary">
                                            <input id="syarikat_surat" name="syarikat_surat" type="checkbox" value="alamat_sama" <?php echo e(old('syarikat_surat',isset($syarikats->syarikat_surat)?$syarikats->syarikat_surat:null) == "alamat_sama" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <label for="syarikat_surat">
                                                Alamat yang sama untuk urusan surat-menyurat
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row mb-sm-2 mb-0">
                                    <label class="col-md-3 col-form-label" for="syarikat_surat"><span class="text-danger">*</span>Alamat syarikat (surat-menyurat):</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_bangunan" name="syarikat_surat_bangunan" class="form-control" placeholder="Bangunan" value="<?php echo e(old('syarikat_surat_bangunan',isset($syarikats->syarikat_surat_bangunan)?$syarikats->syarikat_surat_bangunan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <input type="text" id="syarikat_surat_jalan" name="syarikat_surat_jalan" class="form-control mt-2" placeholder="Jalan" value="<?php echo e(old('syarikat_surat_jalan',isset($syarikats->syarikat_surat_jalan)?$syarikats->syarikat_surat_jalan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_surat_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_surat_tambahan"></label>
                                    <div class="col-md-2 mb-2 mb-sm-0">
                                        <input type="number" id="syarikat_surat_poskod" name="syarikat_surat_poskod" class="form-control" placeholder="Poskod" value="<?php echo e(old('syarikat_surat_poskod',isset($syarikats->syarikat_surat_poskod)?$syarikats->syarikat_surat_poskod:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_surat_poskod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3 mb-2 mb-sm-0">
                                        <input type="text" id="syarikat_surat_bandar" name="syarikat_surat_bandar" class="form-control" placeholder="Bandar" value="<?php echo e(old('syarikat_surat_bandar',isset($syarikats->syarikat_surat_bandar)?$syarikats->syarikat_surat_bandar:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_surat_bandar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3">
                                        <select class="form-control" name="syarikat_surat_negeri" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negeri...</option>
                                            <option value="Johor" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Johor" ? 'selected' : ''); ?>>Johor</option>
                                            <option value="Melaka" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Melaka" ? 'selected' : ''); ?>>Melaka</option>
                                            <option value="Negeri Sembilan" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Negeri Sembilan" ? 'selected' : ''); ?>>Negeri Sembilan</option>
                                            <option value="Selangor" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Selangor" ? 'selected' : ''); ?>>Selangor</option>
                                            <option value="Wilayah Persekutuan Putrajaya, Selangor" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Wilayah Persekutuan Putrajaya, Selangor" ? 'selected' : ''); ?>>Wilayah Persekutuan Putrajaya, Selangor</option>
                                            <option value="Wilayah Persekutuan Kuala Lumpur" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Wilayah Persekutuan Kuala Lumpur" ? 'selected' : ''); ?>>Wilayah Persekutuan Kuala Lumpur</option>
                                            <option value="Pahang" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Pahang" ? 'selected' : ''); ?>>Pahang</option>
                                            <option value="Terengganu" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Terengganu" ? 'selected' : ''); ?>>Terengganu</option>
                                            <option value="Kelantan" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Kelantan" ? 'selected' : ''); ?>>Kelantan</option>
                                            <option value="Perak" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Perak" ? 'selected' : ''); ?>>Perak</option>
                                            <option value="Kedah" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Kedah" ? 'selected' : ''); ?>>Kedah</option>
                                            <option value="Perlis" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Perlis" ? 'selected' : ''); ?>>Perlis</option>
                                            <option value="Pulau Pinang" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Pulau Pinang" ? 'selected' : ''); ?>>Pulau Pinang</option>
                                            <option value="Sabah" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Sabah" ? 'selected' : ''); ?>>Sabah</option>
                                            <option value="Sarawak" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Sarawak" ? 'selected' : ''); ?>>Sarawak</option>
                                            <option value="Wilayah Persekutuan Labuan, Sabah" <?php echo e(old('syarikat_surat_negeri',isset($syarikats->syarikat_surat_negeri)?$syarikats->syarikat_surat_negeri:null) == "Wilayah Persekutuan Labuan, Sabah" ? 'selected' : ''); ?>>Wilayah Persekutuan Labuan, Sabah</option>
                                        </select>                                    
                                        <?php $__errorArgs = ['syarikat_surat_negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_surat_negeri_luar_malaysia">Negeri (luar malaysia):</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_surat_negeri_luar_malaysia" name="syarikat_surat_negeri_luar_malaysia" class="form-control" placeholder="Negeri (luar malaysia)" value="<?php echo e(old('syarikat_surat_negeri_luar_malaysia',isset($syarikats->syarikat_surat_negeri_luar_malaysia)?$syarikats->syarikat_surat_negeri_luar_malaysia:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_surat_negeri_luar_malaysia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_surat_negara"><span class="text-danger">*</span>Negara:</label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="syarikat_surat_negara" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negara...</option>
                                            <?php $__currentLoopData = $list_negara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $negara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($negara->negara_nama); ?>" <?php echo e(old('syarikat_surat_negara' , isset($syarikats->syarikat_surat_negara)?$syarikats->syarikat_surat_negara:null ) == $negara->negara_nama ? 'selected' : ''); ?> ><?php echo e($negara->negara_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>   
                                        <?php $__errorArgs = ['syarikat_surat_negara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_no_tel"><span class="text-danger">*</span>Nombor telefon:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_no_tel" name="syarikat_no_tel" class="form-control" placeholder="Nombor telefon" value="<?php echo e(old('syarikat_no_tel',isset($syarikats->syarikat_no_tel)?$syarikats->syarikat_no_tel:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_no_tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_no_faks">Nombor faks:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_no_faks" name="syarikat_no_faks" class="form-control" placeholder="Nombor faks" value="<?php echo e(old('syarikat_no_faks',isset($syarikats->syarikat_no_faks)?$syarikats->syarikat_no_faks:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_no_faks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_emel"><span class="text-danger">*</span>Emel:</label>
                                    <div class="col-md-8">
                                        <input type="email" id="syarikat_emel" name="syarikat_emel" class="form-control" placeholder="Emel" value="<?php echo e(old('syarikat_emel',isset($syarikats->syarikat_emel)?$syarikats->syarikat_emel:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_emel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="syarikat_wakil">Nama wakil yang dibenarkan:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="syarikat_wakil" name="syarikat_wakil" class="form-control" placeholder="Nama wakil" value="<?php echo e(old('syarikat_wakil',isset($syarikats->syarikat_wakil)?$syarikats->syarikat_wakil:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['syarikat_wakil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                
                                <div class="form-group row mb-0">
                                    <div class="col-8 offset-3">
                                        <?php if($jenis=='new' || $jenis=='kemaskini' ): ?>
                                        <button type="submit" name="syarikat_submit" id="syarikat_submit" class="btn btn-primary waves-effect waves-light mr-1">
                                            <?php echo e($jenis == "kemaskini" ? 'Kemaskini' : 'Daftar'); ?> <i id="loading_icon" class="ml-1 mdi mdi-spin mdi-loading" style="display: none"></i>
                                        </button>
                                        <button type="reset" name="syarikat_batal" id="syarikat_batal" class="btn btn-light waves-effect mr-1">Kosongkan</button>
                                        <?php endif; ?>
                                        <button type="button" onclick="window.location='<?php echo e(route('main.syarikat')); ?>'" name="syarikat_batal" id="syarikat_batal" class="btn btn-light waves-effect">
                                            <?php echo e($jenis == "papar" ? 'Kembali' : 'Batal'); ?>

                                        </button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
    
                </div>
                <!-- end row -->
    
            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

</div>
<!-- end div -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('local_js'); ?>
<script>
$(document).ready(function(){

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('input[name="syarikat_tarikh_roc"]').datepicker();
    $('input[name="syarikat_tarikh_roc"]').attr("placeholder","Tarikh Pendaftaran (ROC) - Pilih dari kalendar");

// copy changes to alamat surat menyurat if checkbox is checked
$("input[name='syarikat_bangunan']").keyup(function(){
    if ($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_bangunan']").val($(this).val());
    }
});
$("input[name='syarikat_jalan']").keyup(function(){
    if ($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_jalan']").val($(this).val());
    }
});
$("input[name='syarikat_poskod']").keyup(function(){
    if ($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_poskod']").val($(this).val());
    }
});
$("input[name='syarikat_bandar']").keyup(function(){
    if ($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_bandar']").val($(this).val());
    }
});
$("input[name='syarikat_negeri_luar_malaysia']").keyup(function(){
    if ($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_negeri_luar_malaysia']").val($(this).val());
    }
});
$("select[name='syarikat_negeri']").on('change', function(){
    if ($('#syarikat_surat').is(":checked")){
        $("select[name='syarikat_surat_negeri']").val($(this).val());
    }
});
$("select[name='syarikat_negara']").on('change', function(){
    if ($('#syarikat_surat').is(":checked")){
        $("select[name='syarikat_surat_negara']").val($(this).val());
    }
});

// copy to alamat surat menyurat if checkbox is checked
$('#syarikat_surat').click(function(){
    changeInputReadonly();
});

// everytime page is reloaded check if the same alamat surat-menyurat is checked
changeInputReadonly();

// search poskod in DB
$("input[name='syarikat_poskod']").on('blur', function(){
    // alert(poskod = $(this).val());
    $.ajax({
            url : "<?php echo e(route('poskod.info')); ?>",
            type : "post",
            data: {'poskod': $(this).val()},
            datatype: 'json',
            // beforeSend: function() {
            //     $('#spinner_confirm_delete').show();
            // },
            success : function(data) {
                // $('#spinner_confirm_delete').hide();
                console.log(data);
                if (data.length>0){
                    $("input[name='syarikat_bandar']").val(data[0].bandar);
                    $("select[name='syarikat_negeri']").val(data[0].negeri);
                    $("select[name='syarikat_negara']").val('Malaysia');
                }
                else {
                    $("input[name='syarikat_bandar']").val('');
                    $("select[name='syarikat_negeri']").val('');
                    $("select[name='syarikat_negara']").val('');
                }
                // alert(data);
            }  
        });
});
$("input[name='syarikat_surat_poskod']").on('blur', function(){
    // alert(poskod = $(this).val());
    $.ajax({
            url : "<?php echo e(route('poskod.info')); ?>",
            type : "post",
            data: {'poskod': $(this).val()},
            datatype: 'json',
            // beforeSend: function() {
            //     $('#spinner_confirm_delete').show();
            // },
            success : function(data) {
                // $('#spinner_confirm_delete').hide();
                console.log(data);
                if (data.length>0){
                    $("input[name='syarikat_surat_bandar']").val(data[0].bandar);
                    $("select[name='syarikat_surat_negeri']").val(data[0].negeri);
                    $("select[name='syarikat_surat_negara']").val('Malaysia');
                }
                else {
                    $("input[name='syarikat_surat_bandar']").val('');
                    $("select[name='syarikat_surat_negeri']").val('');
                    $("select[name='syarikat_surat_negara']").val('');
                }
            }  
        });
});

});

function changeInputReadonly(){
    if($('#syarikat_surat').is(":checked")){
        $("input[name='syarikat_surat_bangunan']").val($("input[name='syarikat_bangunan']").val())
                                            .attr('readonly', true);
        $("input[name='syarikat_surat_jalan']").val($("input[name='syarikat_jalan']").val())
                                            .attr('readonly', true);
        $("input[name='syarikat_surat_poskod']").val($("input[name='syarikat_poskod']").val())
                                            .attr('readonly', true);
        $("input[name='syarikat_surat_bandar']").val($("input[name='syarikat_bandar']").val())
                                            .attr('readonly', true);
        $("input[name='syarikat_surat_negeri_luar_malaysia']").val($("input[name='syarikat_negeri_luar_malaysia']").val())
                                            .attr('readonly', true);
        $("select[name='syarikat_surat_negeri']").val($("select[name='syarikat_negeri'] option:selected").val())
                                            .attr('readonly', true);
        $("select[name='syarikat_surat_negara']").val($("select[name='syarikat_negara'] option:selected").val())
                                            .attr('readonly', true);
    }
    else {     
        $("input[name='syarikat_surat_bangunan']").attr('readonly', false);
        $("input[name='syarikat_surat_jalan']").attr('readonly', false);
        $("input[name='syarikat_surat_poskod']").attr('readonly', false);
        $("input[name='syarikat_surat_bandar']").attr('readonly', false);
        $("input[name='syarikat_surat_negeri_luar_malaysia']").attr('readonly', false);
        $("select[name='syarikat_surat_negeri']").attr('readonly', false);
        $("select[name='syarikat_surat_negara']").attr('readonly', false);
    }
}
</script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Projek\ovvsystem\doa\resources\views/maklumat_am/forms/syarikat.blade.php ENDPATH**/ ?>