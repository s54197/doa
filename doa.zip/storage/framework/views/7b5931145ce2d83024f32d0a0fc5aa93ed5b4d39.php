

<?php $__env->startSection('title', 'Perawis Aktif'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>
    <h4 class="page-title-main">Perawis Aktif</h4>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">DOA</a></li>
        <li class="breadcrumb-item"><a href="#">Rekod Maklumat Am</a></li>
        <li class="breadcrumb-item active">Perawis Aktif</li>
    </ol>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card-box px-4">
                <h4 class="header-title"><?php echo e($tajuk); ?> Perawis</h4>
                <hr class="mb-3">
                
    
                <div class="row">
                    <div class="col-12">
                        <div>
                            <form method="POST" class="form-horizontal" role="form" action="<?php echo e($jenis == 'new' ? route('perawis.create') : route('perawis.update',$perawiss->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_nama"><span class="text-danger">*</span>Nama perawis:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_nama" name="perawis_nama" class="form-control" placeholder="Nama Perawis" value="<?php echo e(old('perawis_nama',isset($perawiss->perawis_nama)?$perawiss->perawis_nama:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_nama_kimia"><span class="text-danger">*</span>Nama Kimia:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_nama_kimia" name="perawis_nama_kimia" class="form-control" placeholder="Nama Kimia" value="<?php echo e(old('perawis_nama_kimia',isset($perawiss->perawis_nama_kimia)?$perawiss->perawis_nama_kimia:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_nama_kimia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_sinonim"><span class="text-danger">*</span>Sinonim:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_sinonim" name="perawis_sinonim" class="form-control" placeholder="Sinonim" value="<?php echo e(old('perawis_sinonim',isset($perawiss->perawis_sinonim)?$perawiss->perawis_sinonim:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_sinonim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_cas"><span class="text-danger">*</span>CAS No:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_cas" name="perawis_cas" class="form-control" placeholder="CAS No" value="<?php echo e(old('perawis_cas',isset($perawiss->perawis_cas)?$perawiss->perawis_cas:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_cas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_hscode"><span class="text-danger">*</span>HSCODE:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_hscode" name="perawis_hscode" class="form-control" placeholder="HSCODE" value="<?php echo e(old('perawis_hscode',isset($perawiss->perawis_hscode)?$perawiss->perawis_hscode:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_hscode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_ahtncode"><span class="text-danger">*</span>AHTNCODE:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_ahtncode" name="perawis_ahtncode" class="form-control" placeholder="AHTNCODE" value="<?php echo e(old('perawis_ahtncode',isset($perawiss->perawis_ahtncode)?$perawiss->perawis_ahtncode:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_ahtncode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_piawaian"><span class="text-danger">*</span>Piawaian Analisis:</label>
                                    <div class="col-md-8">
                                        <div class="checkbox checkbox-primary">
                                            <input id="perawis_piawaian" name="perawis_piawaian" type="checkbox" value="1" <?php echo e(old('perawis_piawaian',isset($borangAs->perawis_piawaian)?$borangAs->perawis_piawaian:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <label for="perawis_piawaian">
                                                
                                            </label>
                                        </div>
                                        <!-- <input type="text" id="perawis_piawaian" name="perawis_piawaian" class="form-control" placeholder="Piawaian Analisis" value="<?php echo e(old('perawis_piawaian',isset($perawiss->perawis_piawaian)?$perawiss->perawis_piawaian:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>> -->
                                        <?php $__errorArgs = ['perawis_piawaian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_sampel"><span class="text-danger">*</span>Sampel Analisis:</label>
                                    <div class="col-md-8">
                                        <div class="checkbox checkbox-primary">
                                            <input id="perawis_sampel" name="perawis_sampel" type="checkbox" value="1" <?php echo e(old('perawis_sampel',isset($borangAs->perawis_sampel)?$borangAs->perawis_sampel:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <label for="perawis_sampel">
                                                
                                            </label>
                                        </div>
                                        <!-- <input type="text" id="perawis_sampel" name="perawis_sampel" class="form-control" placeholder="Sampel Analisis" value="<?php echo e(old('perawis_sampel',isset($perawiss->perawis_sampel)?$perawiss->perawis_sampel:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>> -->
                                        <?php $__errorArgs = ['perawis_sampel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_pihak_ketiga"><span class="text-danger">*</span>Laporan Analisis Makmal Pihak Ketiga:</label>
                                    <div class="col-md-8">
                                        <div class="checkbox checkbox-primary">
                                            <input id="perawis_pihak_ketiga" name="perawis_pihak_ketiga" type="checkbox" value="1" <?php echo e(old('perawis_pihak_ketiga',isset($borangAs->perawis_pihak_ketiga)?$borangAs->perawis_pihak_ketiga:null) == "1" ? 'checked' : ''); ?> <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <label for="perawis_pihak_ketiga">
                                                
                                            </label>
                                        </div>
                                        <!-- <input type="text" id="perawis_pihak_ketiga" name="perawis_pihak_ketiga" class="form-control" placeholder="Laporan Analisis Makmal Pihak Ketiga" value="<?php echo e(old('perawis_pihak_ketiga',isset($perawiss->perawis_pihak_ketiga)?$perawiss->perawis_pihak_ketiga:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>> -->
                                        <?php $__errorArgs = ['perawis_pihak_ketiga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_kumpulan_kimia"><span class="text-danger">*</span>Kumpulan Kimia:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_kumpulan_kimia" name="perawis_kumpulan_kimia" class="form-control" placeholder="Kumpulan Kimia" value="<?php echo e(old('perawis_kumpulan_kimia',isset($perawiss->perawis_kumpulan_kimia)?$perawiss->perawis_kumpulan_kimia:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_kumpulan_kimia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_kaedah"><span class="text-danger">*</span>Kaedah:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="perawis_kaedah" name="perawis_kaedah" class="form-control" placeholder="Kaedah" value="<?php echo e(old('perawis_kaedah',isset($perawiss->perawis_kaedah)?$perawiss->perawis_kaedah:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_kaedah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_tarikh_lulus"><span class="text-danger">*</span>Tarikh Lulus:</label>
                                    <div class="col-md-8">
                                        <input class="form-control" id="perawis_tarikh_lulus" type="text" autocomplete="off" name="perawis_tarikh_lulus" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('perawis_tarikh_lulus',isset($perawiss->perawis_tarikh_lulus)?$perawiss->perawis_tarikh_lulus:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_tarikh_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_tarikh_terhad"><span class="text-danger">*</span>Tarikh Terhad:</label>
                                    <div class="col-md-8">
                                        <input class="form-control" id="perawis_tarikh_terhad" type="text" autocomplete="off" name="perawis_tarikh_terhad" data-date-orientation="bottom" data-date-format="dd-mm-yyyy" value="<?php echo e(old('perawis_tarikh_terhad',isset($perawiss->perawis_tarikh_terhad)?$perawiss->perawis_tarikh_terhad:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_tarikh_terhad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="perawis_peratusan"><span class="text-danger">*</span>Peratusan:</label>
                                    <div class="col-md-3">
                                        <input type="number" id="perawis_peratusan" name="perawis_peratusan" class="form-control" placeholder="Peratusan" value="<?php echo e(old('perawis_peratusan',isset($perawiss->perawis_peratusan)?$perawiss->perawis_peratusan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_peratusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-2">
                                        <select class="form-control" name="perawis_unit" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Unit...</option>
                                            <option value='%w/w' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == '%w/w' ? 'selected' : ''); ?>>%w/w</option>
                                            <option value='mg/mat' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == 'mg/mat' ? 'selected' : ''); ?>>mg/mat</option>
                                            <option value='I.U./mg' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == 'I.U./mg' ? 'selected' : ''); ?>>I.U./mg</option>
                                            <option value='ITU/mg' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == 'ITU/mg' ? 'selected' : ''); ?>>ITU/mg</option>
                                            <option value='mg/unit' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == 'mg/unit' ? 'selected' : ''); ?>>mg/unit</option>
                                            <option value='Lain-lain (nyatakan)' <?php echo e(old('perawis_unit',isset($perawiss->perawis_unit)?$perawiss->perawis_unit:null) == 'Lain-lain (nyatakan)' ? 'selected' : ''); ?>>Lain-lain (nyatakan)</option>
                                        </select>
                                        <?php $__errorArgs = ['perawis_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    </div>
                                    <div class="col-md-3">
                                        <input type="type" id="perawis_unit_lain" name="perawis_unit_lain" class="form-control" placeholder="Maklumat lain-lain" value="<?php echo e(old('perawis_unit_lain',isset($perawiss->perawis_unit_lain)?$perawiss->perawis_unit_lain:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['perawis_unit_lain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mb-0">
                                    <div class="col-8 offset-3">
                                    <?php if($jenis=='new' || $jenis=='kemaskini' ): ?>
                                        <button type="submit" name="perawis_submit" id="perawis_submit" class="btn btn-primary waves-effect waves-light mr-1">
                                            <?php echo e($jenis == "kemaskini" ? 'Kemaskini' : 'Daftar'); ?> <i id="loading_icon" class="ml-1 mdi mdi-spin mdi-loading" style="display: none"></i>
                                        </button>
                                        <button type="reset" name="perawis_batal" id="perawis_batal" class="btn btn-light waves-effect mr-1">Kosongkan</button>
                                        <?php endif; ?>
                                        <button type="button" onclick="window.location='<?php echo e(route('main.perawis')); ?>'" name="perawis_batal" id="perawis_batal" class="btn btn-light waves-effect">
                                            <?php echo e($jenis == "papar" ? 'Kembali' : 'Batal'); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
    
                </div>
                <!-- end row -->
    
            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

</div>
<!-- end div -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('local_js'); ?>
<script>
$(document).ready(function(){
    // initialize date field using datepicker plugin
    $('input[name="perawis_tarikh_lulus"]').datepicker();
    $('input[name="perawis_tarikh_lulus"]').attr("placeholder","Tarikh Lulus - Pilih dari kalendar");
    $('input[name="perawis_tarikh_terhad"]').datepicker();
    $('input[name="perawis_tarikh_terhad"]').attr("placeholder","Tarikh Terhad - Pilih dari kalendar");
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Projek\ovvsystem\doa\resources\views/maklumat_am/forms/perawis.blade.php ENDPATH**/ ?>