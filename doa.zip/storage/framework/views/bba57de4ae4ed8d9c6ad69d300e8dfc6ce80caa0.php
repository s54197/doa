

<?php $__env->startSection('title', 'Pengilang'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>
    <h4 class="page-title-main">Pengilang</h4>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">DOA</a></li>
        <li class="breadcrumb-item"><a href="#">Rekod Maklumat Am</a></li>
        <li class="breadcrumb-item active">Pengilang</li>
    </ol>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card-box px-4">
                <h4 class="header-title"><?php echo e($tajuk); ?> Pengilang</h4>
                <hr class="mb-3">
                
    
                <div class="row">
                    <div class="col-12">
                        <div>
                            <form method="POST" class="form-horizontal" role="form" action="<?php echo e($jenis == 'new' ? route('pengilang.create') : route('pengilang.update',$pengilangs->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_nama"><span class="text-danger">*</span>Nama pengilang:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_nama" name="pihak_ketiga_nama" class="form-control" placeholder="Nama pengilang" value="<?php echo e(old('pihak_ketiga_nama',isset($pengilangs->pihak_ketiga_nama)?$pengilangs->pihak_ketiga_nama:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_no_roc"><span class="text-danger">*</span>Nombor pendaftaran (ROC):</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_no_roc" name="pihak_ketiga_no_roc" class="form-control" placeholder="Nombor Pendaftaran (ROC)" value="<?php echo e(old('pihak_ketiga_no_roc',isset($pengilangs->pihak_ketiga_no_roc)?$pengilangs->pihak_ketiga_no_roc:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_no_roc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mb-0 mb-sm-2">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_alamat"><span class="text-danger">*</span>Alamat pengilang:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_bangunan" name="pihak_ketiga_bangunan" class="form-control" placeholder="Bangunan" value="<?php echo e(old('pihak_ketiga_bangunan',isset($pengilangs->pihak_ketiga_bangunan)?$pengilangs->pihak_ketiga_bangunan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <input type="text" id="pihak_ketiga_jalan" name="pihak_ketiga_jalan" class="form-control mt-2" placeholder="Jalan" value="<?php echo e(old('pihak_ketiga_jalan',isset($pengilangs->pihak_ketiga_jalan)?$pengilangs->pihak_ketiga_jalan:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row mt-0 mt-sm-2 mb-0 mb-sm-2">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_alamat_tambahan"></label>
                                    <div class="col-md-2 mb-2 mb-sm-0">
                                        <input type="number" id="pihak_ketiga_poskod" name="pihak_ketiga_poskod" class="form-control" placeholder="Poskod" value="<?php echo e(old('pihak_ketiga_poskod',isset($pengilangs->pihak_ketiga_poskod)?$pengilangs->pihak_ketiga_poskod:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_poskod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3 mb-2 mb-sm-0">
                                        <input type="text" id="pihak_ketiga_bandar" name="pihak_ketiga_bandar" class="form-control" placeholder="Bandar" value="<?php echo e(old('pihak_ketiga_bandar',isset($pengilangs->pihak_ketiga_bandar)?$pengilangs->pihak_ketiga_bandar:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_bandar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                    <div class="col-md-3">
                                        <select class="form-control" name="pihak_ketiga_negeri" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negeri...</option>
                                            <option value="Johor" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Johor" ? 'selected' : ''); ?>>Johor</option>
                                            <option value="Melaka" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Melaka" ? 'selected' : ''); ?>>Melaka</option>
                                            <option value="Negeri Sembilan" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Negeri Sembilan" ? 'selected' : ''); ?>>Negeri Sembilan</option>
                                            <option value="Selangor" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Selangor" ? 'selected' : ''); ?>>Selangor</option>
                                            <option value="Wilayah Persekutuan Putrajaya, Selangor" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Wilayah Persekutuan Putrajaya, Selangor" ? 'selected' : ''); ?>>Wilayah Persekutuan Putrajaya, Selangor</option>
                                            <option value="Wilayah Persekutuan Kuala Lumpur" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Wilayah Persekutuan Kuala Lumpur" ? 'selected' : ''); ?>>Wilayah Persekutuan Kuala Lumpur</option>
                                            <option value="Pahang" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Pahang" ? 'selected' : ''); ?>>Pahang</option>
                                            <option value="Terengganu" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Terengganu" ? 'selected' : ''); ?>>Terengganu</option>
                                            <option value="Kelantan" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Kelantan" ? 'selected' : ''); ?>>Kelantan</option>
                                            <option value="Perak" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Perak" ? 'selected' : ''); ?>>Perak</option>
                                            <option value="Kedah" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Kedah" ? 'selected' : ''); ?>>Kedah</option>
                                            <option value="Perlis" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Perlis" ? 'selected' : ''); ?>>Perlis</option>
                                            <option value="Pulau Pinang" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Pulau Pinang" ? 'selected' : ''); ?>>Pulau Pinang</option>
                                            <option value="Sabah" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Sabah" ? 'selected' : ''); ?>>Sabah</option>
                                            <option value="Sarawak" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Sarawak" ? 'selected' : ''); ?>>Sarawak</option>
                                            <option value="Wilayah Persekutuan Labuan, Sabah" <?php echo e(old('pihak_ketiga_negeri',isset($pengilangs->pihak_ketiga_negeri)?$pengilangs->pihak_ketiga_negeri:null) == "Wilayah Persekutuan Labuan, Sabah" ? 'selected' : ''); ?>>Wilayah Persekutuan Labuan, Sabah</option>
                                        </select>                                    
                                        <?php $__errorArgs = ['pihak_ketiga_negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_negeri_luar_malaysia">Negeri (luar malaysia) pengilang:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_negeri_luar_malaysia" name="pihak_ketiga_negeri_luar_malaysia" class="form-control" placeholder="Negeri (luar malaysia) pengilang" value="<?php echo e(old('pihak_ketiga_negeri_luar_malaysia',isset($pengilangs->pihak_ketiga_negeri_luar_malaysia)?$pengilangs->pihak_ketiga_negeri_luar_malaysia:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_negeri_luar_malaysia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_negara"><span class="text-danger">*</span>Negara pengilang:</label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="pihak_ketiga_negara" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Negara...</option>
                                            <?php $__currentLoopData = $list_negara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $negara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($negara->negara_nama); ?>" <?php echo e(old('pihak_ketiga_negara' , isset($pengilangs->pihak_ketiga_negara)?$pengilangs->pihak_ketiga_negara:null ) == $negara->negara_nama ? 'selected' : ''); ?> ><?php echo e($negara->negara_nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>   
                                        <?php $__errorArgs = ['pihak_ketiga_negara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_no_tel"><span class="text-danger">*</span>Nombor telefon:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_no_tel" name="pihak_ketiga_no_tel" class="form-control" placeholder="Nama telefon" value="<?php echo e(old('pihak_ketiga_no_tel',isset($pengilangs->pihak_ketiga_no_tel)?$pengilangs->pihak_ketiga_no_tel:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_no_tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_no_faks">Nombor faks:</label>
                                    <div class="col-md-8">
                                        <input type="text" id="pihak_ketiga_no_faks" name="pihak_ketiga_no_faks" class="form-control" placeholder="Nombor faks" value="<?php echo e(old('pihak_ketiga_no_faks',isset($pengilangs->pihak_ketiga_no_faks)?$pengilangs->pihak_ketiga_no_faks:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_no_faks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label" for="pihak_ketiga_emel"><span class="text-danger">*</span>Emel:</label>
                                    <div class="col-md-8">
                                        <input type="email" id="pihak_ketiga_emel" name="pihak_ketiga_emel" class="form-control" placeholder="Emel" value="<?php echo e(old('pihak_ketiga_emel',isset($pengilangs->pihak_ketiga_emel)?$pengilangs->pihak_ketiga_emel:null)); ?>" <?php echo e($tajuk == "Paparan" ? 'disabled' : ''); ?>>
                                        <?php $__errorArgs = ['pihak_ketiga_emel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        <small class='text-danger'><?php echo e($message); ?></small> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                
                                    </div>
                                </div>
                                
                                <div class="form-group row mb-0">
                                    <div class="col-8 offset-3">
                                        <?php if($jenis=='new' || $jenis=='kemaskini' ): ?>
                                        <button type="submit" name="pihak_ketiga_submit" id="pihak_ketiga_submit" class="btn btn-primary waves-effect waves-light mr-1">
                                            <?php echo e($jenis == "kemaskini" ? 'Kemaskini' : 'Daftar'); ?> <i id="loading_icon" class="ml-1 mdi mdi-spin mdi-loading" style="display: none"></i>
                                        </button>
                                        <button type="reset" name="pihak_ketiga_batal" id="pihak_ketiga_batal" class="btn btn-light waves-effect mr-1">Kosongkan</button>
                                        <?php endif; ?>
                                        <button type="button" onclick="window.location='<?php echo e(route('main.pengilang')); ?>'" name="pihak_ketiga_batal" id="pihak_ketiga_batal" class="btn btn-light waves-effect">
                                            <?php echo e($jenis == "papar" ? 'Kembali' : 'Batal'); ?>

                                        </button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
    
                </div>
                <!-- end row -->
    
            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

</div>
<!-- end div -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('local_js'); ?>
<script>
$(document).ready(function(){
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    // search poskod in DB
    $("input[name='pihak_ketiga_poskod']").on('blur', function(){
        // alert(poskod = $(this).val());
        $.ajax({
            url : "<?php echo e(route('poskod.info')); ?>",
            type : "post",
            data: {'poskod': $(this).val()},
            datatype: 'json',
            // beforeSend: function() {
            //     $('#spinner_confirm_delete').show();
            // },
            success : function(data) {
                // $('#spinner_confirm_delete').hide();
                console.log(data);
                if (data.length>0){
                    $("input[name='pihak_ketiga_bandar']").val(data[0].bandar);
                    $("select[name='pihak_ketiga_negeri']").val(data[0].negeri);
                    $("select[name='pihak_ketiga_negara']").val('Malaysia');
                }
                else {
                    $("input[name='pihak_ketiga_bandar']").val('');
                    $("select[name='pihak_ketiga_negeri']").val('');
                    $("select[name='pihak_ketiga_negara']").val('');
                }
                // alert(data);
            }  
        });
    });
});
</script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Projek\ovvsystem\doa\resources\views/maklumat_am/forms/pengilang.blade.php ENDPATH**/ ?>